package com.example.extract_csv;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class ExtractCsvApplication {

	public static void main(String[] args) {
		SpringApplication.run(ExtractCsvApplication.class, args);
	}
}
